package domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class User {
	private String user_name;
	private String user_password;
	private String user_phone;
	private String user_sex;
	private String user_id;
}
